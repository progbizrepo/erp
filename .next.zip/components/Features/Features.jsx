import React from 'react'

import UniqueFeatureSection from '../UniqueFeatureSection/UniqueFeatureSection';


const Features = () => {
 
  return (
   <>
    <UniqueFeatureSection/>
  </>
  )
}

export default Features