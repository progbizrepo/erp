import React from 'react'
import HeroBackground from './HeroBackground'
// import Description from "@/components/Description/Description";
import Index from '../Index/Index';
import Image from 'next/image';



const Hero = () => {
  return (
    <>
   
  
 <section className='backgroundShadow' >

    
 <HeroBackground/>

 </section>
    </>
  )
}

export default Hero
